package com.example.mictotws

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var btn: Button
    private lateinit var info: TextView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(
                dp(24), ins.systemWindowInsetTop + dp(32),
                dp(24), ins.systemWindowInsetBottom + dp(24)
            )
            ins
        }

        val title = TextView(this).apply {
            text = "Телефон как микрофон"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        info = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(24))
        }
        btn = Button(this).apply {
            textSize = 20f
            setOnClickListener { toggle() }
        }
        val volLabel = TextView(this).apply {
            text = "Громкость: 100%"
            textSize = 16f
            setPadding(0, dp(32), 0, dp(8))
        }
        val seek = SeekBar(this).apply {
            max = 300
            progress = (MicService.gain * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    MicService.gain = p / 100f
                    volLabel.text = "Громкость: $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        volLabel.text = "Громкость: ${seek.progress}%"

        root.addView(title)
        root.addView(info)
        root.addView(btn, LinearLayout.LayoutParams(-1, dp(72)))
        root.addView(volLabel)
        root.addView(seek, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        btn.text = if (MicService.active) "Выключить" else "Включить"
        info.text = if (MicService.active)
            "Работает. Микрофон телефона → наушники."
        else
            "Подключите iQOO TWS 5 по Bluetooth и нажмите «Включить»."
    }

    private fun toggle() {
        if (MicService.active) {
            startService(Intent(this, MicService::class.java).setAction(MicService.ACTION_STOP))
            btn.postDelayed({ refresh() }, 300)
            return
        }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else startMic()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startMic()
        else
            info.text = "Без разрешения на микрофон приложение не работает."
    }

    private fun startMic() {
        startForegroundService(Intent(this, MicService::class.java))
        btn.postDelayed({ refresh() }, 400)
    }
}

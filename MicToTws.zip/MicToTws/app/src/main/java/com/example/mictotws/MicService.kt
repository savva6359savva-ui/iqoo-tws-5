package com.example.mictotws

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast

/** Читает микрофон телефона и сразу играет звук в наушники. */
class MicService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.mictotws.STOP"
        @Volatile var gain = 1.0f
        @Volatile var active = false
    }

    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        goForeground()
        running = true
        active = true
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("mic", "Микрофон", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, MicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            "Выключить", stop
        ).build()
        val n = Notification.Builder(this, "mic")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Микрофон → наушники")
            .setContentText("Телефон передаёт звук в наушники")
            .setOngoing(true)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun isHeadphones(d: AudioDeviceInfo): Boolean =
        d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            d.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            d.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            d.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
            (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)

    private fun fail(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun loop() {
        val am = getSystemService(AudioManager::class.java)
        val rate = 48000

        // Без наушников звук ушёл бы в динамик телефона и дал бы свист.
        val out = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { isHeadphones(it) }
        if (out == null) {
            fail("Наушники не подключены. Подключите TWS 5 и включите снова.")
            return
        }

        val minIn = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minOut = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )

        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minIn * 2
        )
        // Берём именно микрофон телефона, а не микрофон наушников.
        am.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            ?.let { rec.setPreferredDevice(it) }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minOut)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track.setPreferredDevice(out)

        val buf = ShortArray(960)
        try {
            rec.startRecording()
            track.play()
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                val g = gain
                for (i in 0 until n) {
                    val v = (buf[i] * g).toInt().coerceIn(-32768, 32767)
                    buf[i] = v.toShort()
                }
                track.write(buf, 0, n)
            }
        } catch (e: Exception) {
            fail("Ошибка звука: ${e.message}")
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            try { track.stop() } catch (_: Exception) {}
            track.release()
        }
    }

    override fun onDestroy() {
        running = false
        active = false
        try { worker?.join(500) } catch (_: InterruptedException) {}
        super.onDestroy()
    }
}
